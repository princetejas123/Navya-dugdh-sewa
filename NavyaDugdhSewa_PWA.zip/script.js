document.addEventListener("DOMContentLoaded", function () {
  const loginForm = document.getElementById("login-form");
  if (loginForm) {
    loginForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const name = document.getElementById("name").value.trim();
      const address = document.getElementById("address").value.trim();
      const mobile = document.getElementById("mobile").value.trim();
      if (name && address && mobile) {
        alert(`🙏 स्वागत है, ${name} जी!\n✅ आपने सफलतापूर्वक लॉगिन किया है।`);
        loginForm.reset();
      } else {
        alert("❌ कृपया सभी जानकारी भरें।");
      }
    });
  }
});